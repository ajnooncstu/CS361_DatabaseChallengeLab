# CS361 Database Architecture Benchmark (v3, Café schema)

A teaching harness that runs the **Café application's own order workload** against **Amazon RDS for MariaDB** and **Amazon DynamoDB**.

> Classroom experiment, not a production benchmark. Results support claims only about the tested configuration, workload, data, Region and client.

## The data: the Café schema from the previous lab

`setup_rds.sql` creates a separate database, `cs361lab`, with the **same tables as the Café's `cafe_db`** (`product_group`, `product`, `order`, `order_item`) and the same 9 menu products. The Café website's own `cafe_db` is never touched.

`seed.py` loads 1,000 orders (1–3 menu items each) into both databases.

DynamoDB stores each order as an **item collection** (several items under one partition key):

| pk | sk | Attributes | Like |
|---|---|---|---|
| `ORDER#42` | `META` | order_date_time, amount, items (copy), gsi1pk, gsi1sk | a row of `order` |
| `ORDER#42` | `ITEM#1` | product_id, product_name, quantity, amount | a row of `order_item` |

`create_dynamodb_table.py` also creates **OrderHistoryIndex**, a global secondary index (GSI) on `gsi1pk = ORDERS`, `gsi1sk = <order_date_time>#<order_number>`. Only META items carry these keys, so the index lists orders newest first. It exists from the start so nobody waits for it in class; the starter `history` workload ignores it.

## Workloads

| Workload | Café page | RDS | DynamoDB |
|---|---|---|---|
| `read` | Order Confirmation | SELECT … JOIN order_item, product WHERE order_number = ? | Query pk = ORDER#n |
| `write` | Submit Order | INSERT `order` + INSERT order_item rows, one transaction | TransactWriteItems (META + ITEM#) |
| `history` | Order History (20 newest) | `orderHistory.php` query + LIMIT 20 orders | Scan every page, then sort (starter design) |
| `history-gsi` | Order History (20 newest) | n/a | Query OrderHistoryIndex, newest first, Limit 20 |

DynamoDB has no AUTO_INCREMENT, so the write workload creates order numbers in the application.

## 1. Install (on the Café EC2 instance)

```bash
python3 --version                # 3.7 or newer (Amazon Linux 2 ships 3.7)
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env             # then edit .env
python check_setup.py            # every line must say OK
```

If DynamoDB is in a Learner Lab account, paste its `[default]` credentials block into `~/.aws/credentials` and set `AWS_REGION` in `.env` to that Region.

## 2. Create and load the data

```bash
mysql -h YOUR_RDS_ENDPOINT -u admin -p < setup_rds.sql
python create_dynamodb_table.py
python seed.py --db both --records 1000
```

Both lines must say `verified 1000 seed orders with N order items`, with the same N.

## 3. Run the experiments (one command each)

```bash
python run_experiment.py read      # A: one order + items at concurrency 1, 5, 10, 25
python run_experiment.py write     # B: place an order at concurrency 1 and 10
python run_experiment.py rush      # C: Songkran rush, 150 clients placing orders at once
python run_experiment.py history   # D: Order History page, Scan vs OrderHistoryIndex
```

Each prints a table of medians over 3 runs and appends every run to `results.csv`. Use `--quick` for a fast setup check (1 run, 1/10 of the requests; not for results). If the client cannot start 150 threads, use `--rush-concurrency 100`.

Table columns: `p50`/`p95` latency of successful requests, `req/s` throughput, `Errors` (failed/total), `Retries` (requests the AWS SDK retried, e.g. after throttling), `Rows` (order lines for read/write, orders for history), `Scanned` (DynamoDB items read per history request).

`rush` also prints the RDS `max_connections`. Each benchmark thread keeps one connection, so more threads than that limit produce `Too many connections` errors on RDS. DynamoDB is called over HTTPS and has no connection limit.

## 4. Single runs (optional)

`benchmark.py` runs one configuration:

```bash
python benchmark.py --db rds --workload read --requests 1000 --concurrency 10
python benchmark.py --db dynamodb --workload history-gsi --requests 200 --concurrency 10
python benchmark.py --db rds --workload read --requests 1000 --concurrency 10 --new-connection-per-request
```

It prints `start_utc`/`end_utc` for finding the run in CloudWatch (metrics are per minute; use `--requests 5000` or more).

## Notes

- Write tests add orders to both databases in the same way, so later history tests scan more DynamoDB items.
- Cleanup: `DROP DATABASE cs361lab;` on RDS and delete the `cs361-orders` table, if your instructor asks.
- Some AWS Academy environments block DynamoDB. Use the instructor-approved Learner Lab in that case.
