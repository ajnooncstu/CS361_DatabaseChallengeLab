/*
  CS361 benchmark database.
  The tables below copy the Cafe application's cafe_db schema (product_group, product,
  order, order_item) into a SEPARATE database, cs361lab, so the benchmark never touches
  the cafe website's own data. The 9 products are the Cafe menu.
*/
CREATE DATABASE IF NOT EXISTS cs361lab;
USE cs361lab;

CREATE TABLE IF NOT EXISTS product_group (
  product_group_number INT(3) NOT NULL PRIMARY KEY,
  product_group_name VARCHAR(25) NOT NULL DEFAULT ''
);

INSERT IGNORE INTO product_group (product_group_number, product_group_name) VALUES
    (1, 'Pastries')
  , (2, 'Drinks');

CREATE TABLE IF NOT EXISTS product (
  id INT(3) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(40) NOT NULL DEFAULT '',
  description VARCHAR(200) NOT NULL DEFAULT '',
  price DECIMAL(10,2) NOT NULL DEFAULT 0.0,
  product_group INT(2) NOT NULL DEFAULT 1,
  image_url VARCHAR(256) DEFAULT 'images/default-image.jpg',
  FOREIGN KEY (product_group) REFERENCES product_group (product_group_number)
);

INSERT IGNORE INTO product (id, product_name, description, price, product_group, image_url) VALUES
    (1, 'Croissant', 'Fresh, buttery and fluffy... Simply delicious!', 1.50, 1, 'images/Croissants.jpg')
  , (2, 'Donut', 'We have more than half-a-dozen flavors!', 1.00, 1, 'images/Donuts.jpg')
  , (3, 'Chocolate Chip Cookie', 'Made with Swiss chocolate with a touch of Madagascar vanilla', 2.50, 1, 'images/Chocolate-Chip-Cookies.jpg')
  , (4, 'Muffin', 'Banana bread, blueberry, cranberry or apple', 3.00, 1, 'images/Muffins.jpg')
  , (5, 'Strawberry Blueberry Tart', 'Bursting with the taste and aroma of fresh fruit', 3.50, 1, 'images/Strawberry-Blueberry-Tarts.jpg')
  , (6, 'Strawberry Tart', 'Made with fresh ripe strawberries and a delicious whipped cream', 3.50, 1, 'images/Strawberry-Tarts.jpg')
  , (7, 'Coffee', 'Freshly-ground black or blended Columbian coffee', 3.00, 2, 'images/Coffee.jpg')
  , (8, 'Hot Chocolate', 'Rich and creamy, and made with real chocolate', 3.00, 2, 'images/Cup-of-Hot-Chocolate.jpg')
  , (9, 'Latte', 'Offered hot or cold and in various delicious flavors', 3.50, 2, 'images/Latte.jpg');

CREATE TABLE IF NOT EXISTS `order` (
  order_number INT(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_date_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS order_item (
  order_number INT(5) NOT NULL,
  order_item_number INT(5) NOT NULL,
  product_id INT(3),
  quantity INT(2),
  amount DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (order_number, order_item_number),
  FOREIGN KEY (order_number) REFERENCES `order` (order_number),
  FOREIGN KEY (product_id) REFERENCES product (id)
);
