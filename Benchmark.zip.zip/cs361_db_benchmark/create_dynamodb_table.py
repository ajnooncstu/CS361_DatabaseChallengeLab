"""Create the DynamoDB table for the Cafe orders.

Base table (the starter design, like the Cafe's order + order_item tables):
  pk = ORDER#<order_number>, sk = META          -> order_date_time, amount, items (copy for the history page)
  pk = ORDER#<order_number>, sk = ITEM#<number> -> product_id, product_name, quantity, amount

OrderHistoryIndex (a global secondary index, GSI) is created now so nobody waits for it in class.
Only META items carry its keys, so it lists orders only, newest first:
  gsi1pk = ORDERS, gsi1sk = <order_date_time>#<order_number>
The starter history workload ignores this index; the history-gsi workload uses it.
"""
import os

import boto3
from dotenv import load_dotenv

load_dotenv()
region = os.getenv("AWS_REGION", "us-east-1")
table_name = os.getenv("DDB_TABLE", "cs361-orders")

ddb = boto3.client("dynamodb", region_name=region)

try:
    desc = ddb.describe_table(TableName=table_name)["Table"]
    gsis = [g["IndexName"] for g in desc.get("GlobalSecondaryIndexes", [])]
    print(f"Table already exists: {table_name} (indexes: {', '.join(gsis) or 'none'})")
    if "OrderHistoryIndex" not in gsis:
        print("WARNING: OrderHistoryIndex is missing. Delete the table and run this script again.")
    raise SystemExit(0)
except ddb.exceptions.ResourceNotFoundException:
    pass

ddb.create_table(
    TableName=table_name,
    KeySchema=[
        {"AttributeName": "pk", "KeyType": "HASH"},
        {"AttributeName": "sk", "KeyType": "RANGE"},
    ],
    AttributeDefinitions=[
        {"AttributeName": "pk", "AttributeType": "S"},
        {"AttributeName": "sk", "AttributeType": "S"},
        {"AttributeName": "gsi1pk", "AttributeType": "S"},
        {"AttributeName": "gsi1sk", "AttributeType": "S"},
    ],
    GlobalSecondaryIndexes=[
        {
            "IndexName": "OrderHistoryIndex",
            "KeySchema": [
                {"AttributeName": "gsi1pk", "KeyType": "HASH"},
                {"AttributeName": "gsi1sk", "KeyType": "RANGE"},
            ],
            "Projection": {"ProjectionType": "ALL"},
        }
    ],
    BillingMode="PAY_PER_REQUEST",
)
print(f"Creating table {table_name} with OrderHistoryIndex...")
ddb.get_waiter("table_exists").wait(TableName=table_name)
print(f"Ready: {table_name}")
