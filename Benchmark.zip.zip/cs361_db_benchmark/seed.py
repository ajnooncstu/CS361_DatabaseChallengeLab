"""Load the same Cafe orders (order + order_item rows) into RDS and DynamoDB.

RDS:      cs361lab.`order` and cs361lab.order_item (the Cafe schema, see setup_rds.sql)
DynamoDB: one item collection per order
            pk = ORDER#<order_number>, sk = META                 -> order_date_time, amount, items copy,
                                                                    OrderHistoryIndex keys
            pk = ORDER#<order_number>, sk = ITEM#<item_number>  -> product_id, product_name, quantity, amount
Running it again is safe: the same orders are overwritten.
"""
import argparse
import os

import boto3
import pymysql
from dotenv import load_dotenv

from cafe_data import ddb_items, seed_order

load_dotenv()


def rds_conn():
    return pymysql.connect(
        host=os.environ["RDS_HOST"],
        port=int(os.getenv("RDS_PORT", "3306")),
        user=os.environ["RDS_USER"],
        password=os.environ["RDS_PASSWORD"],
        database=os.getenv("RDS_DATABASE", "cs361lab"),
        autocommit=False,
        connect_timeout=10,
        read_timeout=60,
        write_timeout=60,
    )


def seed_rds(n):
    conn = rds_conn()
    try:
        with conn.cursor() as cur:
            orders = [seed_order(k) for k in range(1, n + 1)]
            cur.executemany(
                "INSERT INTO `order` (order_number, order_date_time, amount) VALUES (%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE order_date_time=VALUES(order_date_time), amount=VALUES(amount)",
                [(o["order_number"], o["order_date_time"], o["amount"]) for o in orders],
            )
            cur.executemany(
                "INSERT INTO order_item (order_number, order_item_number, product_id, quantity, amount) "
                "VALUES (%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE product_id=VALUES(product_id), "
                "quantity=VALUES(quantity), amount=VALUES(amount)",
                [(o["order_number"], it["order_item_number"], it["product_id"], it["quantity"], it["amount"])
                 for o in orders for it in o["items"]],
            )
            conn.commit()
            cur.execute("SELECT COUNT(*) FROM `order` WHERE order_number <= %s", (n,))
            n_orders = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM order_item WHERE order_number <= %s", (n,))
            n_items = cur.fetchone()[0]
        print(f"RDS: wrote {n} orders -> verified {n_orders} seed orders with {n_items} order items")
    finally:
        conn.close()


def seed_ddb(n):
    table = boto3.resource("dynamodb", region_name=os.getenv("AWS_REGION", "us-east-1")).Table(
        os.getenv("DDB_TABLE", "cs361-orders")
    )
    with table.batch_writer(overwrite_by_pkeys=["pk", "sk"]) as batch:
        for k in range(1, n + 1):
            for item in ddb_items(k, seed_order(k)):
                batch.put_item(Item=item)

    def count(**filt):
        total, kwargs = 0, {"Select": "COUNT", **filt}
        while True:  # COUNT scans page by page; follow LastEvaluatedKey to count everything
            r = table.scan(**kwargs)
            total += r["Count"]
            if "LastEvaluatedKey" not in r:
                return total
            kwargs["ExclusiveStartKey"] = r["LastEvaluatedKey"]

    n_orders = count(FilterExpression="sk = :m AND order_number <= :n",
                     ExpressionAttributeValues={":m": "META", ":n": n})
    n_items = count(FilterExpression="begins_with(sk, :i) AND order_number <= :n",
                    ExpressionAttributeValues={":i": "ITEM#", ":n": n})
    print(f"DynamoDB: wrote {n} orders -> verified {n_orders} seed orders with {n_items} order items")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--db", choices=["rds", "dynamodb", "both"], required=True)
    p.add_argument("--records", type=int, default=1000, help="number of Cafe orders")
    args = p.parse_args()
    if args.db in ("rds", "both"):
        seed_rds(args.records)
    if args.db in ("dynamodb", "both"):
        seed_ddb(args.records)
