"""Run this first (Part 2). It checks everything the benchmark needs, one line per check."""
import os
import sys

REQUIRED = (3, 7)
ok_all = True


def report(ok, label, detail=""):
    global ok_all
    ok_all &= ok
    print(f"[{'OK ' if ok else 'FAIL'}] {label}" + (f" - {detail}" if detail else ""))


report(sys.version_info >= REQUIRED, "Python version",
       f"{sys.version.split()[0]} (need {REQUIRED[0]}.{REQUIRED[1]}+; use python3)")

try:
    from dotenv import load_dotenv
    import boto3
    import pymysql
    load_dotenv()
    report(True, "Packages installed", f"boto3 {boto3.__version__}, PyMySQL {pymysql.__version__}")
except ImportError as e:
    report(False, "Packages installed", f"{e}. Run: pip install -r requirements.txt")
    sys.exit(1)

region = os.getenv("AWS_REGION", "us-east-1")
table = os.getenv("DDB_TABLE", "cs361-orders")
print(f"       AWS_REGION={region}  DDB_TABLE={table}  RDS_HOST={os.getenv('RDS_HOST')}")

# RDS
try:
    conn = pymysql.connect(host=os.environ["RDS_HOST"], port=int(os.getenv("RDS_PORT", "3306")),
                           user=os.environ["RDS_USER"], password=os.environ["RDS_PASSWORD"],
                           connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("SELECT VERSION()")
        report(True, "RDS reachable", f"server {cur.fetchone()[0]}")
    conn.close()
except KeyError as e:
    report(False, "RDS reachable", f"{e} missing in .env")
except Exception as e:  # noqa: BLE001
    report(False, "RDS reachable", f"{type(e).__name__}: {e}. Run from the Cafe EC2 instance; "
                                   "RDS only accepts connections from its security group.")

# AWS credentials + DynamoDB
try:
    ident = boto3.client("sts", region_name=region).get_caller_identity()
    report(True, "AWS credentials", f"account {ident['Account']}")
except Exception as e:  # noqa: BLE001
    report(False, "AWS credentials", f"{type(e).__name__}: {e}")

try:
    boto3.client("dynamodb", region_name=region).list_tables(Limit=1)
    report(True, "DynamoDB allowed", f"in {region}")
except Exception as e:  # noqa: BLE001
    report(False, "DynamoDB allowed", f"{type(e).__name__}: {e}. Use the instructor-approved Learner Lab "
                                      "credentials (incl. AWS_SESSION_TOKEN) in .env.")

print("\nAll checks passed." if ok_all else "\nFix the FAIL lines before continuing.")
sys.exit(0 if ok_all else 1)
