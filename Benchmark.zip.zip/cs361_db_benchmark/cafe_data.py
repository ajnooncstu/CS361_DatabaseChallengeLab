"""The Cafe menu and a deterministic order generator shared by seed.py and benchmark.py."""
import datetime as dt
import random
from decimal import Decimal

# Same 9 products as the Cafe application's cafe_db.product table.
PRODUCTS = {
    1: ("Croissant", Decimal("1.50")),
    2: ("Donut", Decimal("1.00")),
    3: ("Chocolate Chip Cookie", Decimal("2.50")),
    4: ("Muffin", Decimal("3.00")),
    5: ("Strawberry Blueberry Tart", Decimal("3.50")),
    6: ("Strawberry Tart", Decimal("3.50")),
    7: ("Coffee", Decimal("3.00")),
    8: ("Hot Chocolate", Decimal("3.00")),
    9: ("Latte", Decimal("3.50")),
}

SEED_START = dt.datetime(2026, 6, 1, 7, 0, 0)


def make_items(rng):
    """1-3 different products, quantity 1-3 each, like one Cafe order form."""
    items = []
    for n, pid in enumerate(rng.sample(sorted(PRODUCTS), rng.randint(1, 3)), start=1):
        qty = rng.randint(1, 3)
        items.append({"order_item_number": n, "product_id": pid, "product_name": PRODUCTS[pid][0],
                      "quantity": qty, "amount": PRODUCTS[pid][1] * qty})
    return items


def seed_order(order_number):
    """Order 1..N: the same order (date, items, amounts) every time, for both databases."""
    rng = random.Random(order_number)
    items = make_items(rng)
    when = SEED_START + dt.timedelta(minutes=120 * (order_number - 1) + rng.randint(0, 90))
    return {
        "order_number": order_number,
        "order_date_time": when.strftime("%Y-%m-%d %H:%M:%S"),
        "amount": sum(i["amount"] for i in items),
        "items": items,
    }


def new_order(i):
    """A new order placed during the write benchmark (date = now)."""
    items = make_items(random.Random(i))
    return {
        "order_date_time": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "amount": sum(x["amount"] for x in items),
        "items": items,
    }


def ddb_items(order_number, o):
    """The DynamoDB items for one order: META (with the GSI keys and a copy of the items for
    the Order History page) + one ITEM# item per order line, like order_item."""
    pk = f"ORDER#{order_number}"
    lines = [{k: it[k] for k in ("order_item_number", "product_id", "product_name", "quantity", "amount")}
             for it in o["items"]]
    meta = {
        "pk": pk, "sk": "META", "order_number": order_number,
        "order_date_time": o["order_date_time"], "amount": o["amount"],
        "items": lines,                                   # denormalized copy for the history page
        "gsi1pk": "ORDERS",                               # OrderHistoryIndex partition key
        "gsi1sk": f"{o['order_date_time']}#{order_number:020d}",  # newest first when sorted descending
    }
    return [meta] + [{"pk": pk, "sk": f"ITEM#{ln['order_item_number']}", "order_number": order_number, **ln}
                     for ln in lines]
