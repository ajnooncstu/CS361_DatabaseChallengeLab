"""Run one whole lab experiment with a single command and print a table of medians.

    python run_experiment.py read      # experiment A: one order + items, concurrency 1, 5, 10, 25
    python run_experiment.py write     # experiment B: place an order, concurrency 1 and 10
    python run_experiment.py rush      # experiment C: Songkran rush, 150 clients placing orders at once
    python run_experiment.py history   # experiment D: Order History page, Scan vs OrderHistoryIndex

Every run is also appended to results.csv. Each table row is the MEDIAN of --repeats runs
(default 3); the errors column is the total over all runs.
Options: --repeats N, --rush-concurrency N (if the client machine cannot start 150 threads),
         --quick (1 run with 1/10 of the requests: a fast check that everything works, not for results).
"""
import argparse
import csv
import os
import statistics
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))

PLANS = {
    "read": {"warmup": True, "repeats": None,
             "runs": [(db, "read", 1000, c) for c in (1, 5, 10, 25) for db in ("rds", "dynamodb")]},
    "write": {"warmup": False, "repeats": None,
              "runs": [(db, "write", 500, c) for c in (1, 10) for db in ("rds", "dynamodb")]},
    "rush": {"warmup": False, "repeats": 1,
             "runs": [(db, "write", 1500, 150) for db in ("rds", "dynamodb")]},
    "history": {"warmup": False, "repeats": None,
                "runs": [("rds", "history", 200, 10), ("dynamodb", "history", 200, 10),
                         ("dynamodb", "history-gsi", 200, 10)]},
}


def run_once(db, workload, requests, concurrency, out_csv):
    tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
    tmp.close()
    os.unlink(tmp.name)
    cmd = [sys.executable, os.path.join(HERE, "benchmark.py"), "--db", db, "--workload", workload,
           "--requests", str(requests), "--concurrency", str(concurrency), "--out", tmp.name]
    proc = subprocess.run(cmd, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          universal_newlines=True)
    if proc.returncode != 0 or not os.path.exists(tmp.name):
        print(proc.stdout)
        sys.exit(f"benchmark.py failed for {db} {workload}; fix the error above and run again.")
    first_error = next((ln.split("=", 1)[1].strip() for ln in proc.stdout.splitlines()
                        if ln.startswith("first_error=")), "")
    with open(tmp.name) as fh:
        row = list(csv.DictReader(fh))[-1]
    os.unlink(tmp.name)
    new = not os.path.exists(out_csv)
    with open(out_csv, "a", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(row))
        if new:
            w.writeheader()
        w.writerow(row)
    return row, first_error


def rds_max_connections():
    try:
        from dotenv import load_dotenv
        import pymysql
        load_dotenv(os.path.join(HERE, ".env"))
        conn = pymysql.connect(host=os.environ["RDS_HOST"], port=int(os.getenv("RDS_PORT", "3306")),
                               user=os.environ["RDS_USER"], password=os.environ["RDS_PASSWORD"],
                               connect_timeout=5)
        with conn.cursor() as cur:
            cur.execute("SHOW VARIABLES LIKE 'max_connections'")
            value = cur.fetchone()[1]
            cur.execute("SHOW STATUS LIKE 'Threads_connected'")
            used = cur.fetchone()[1]
        conn.close()
        return f"{value} (currently connected: {used})"
    except Exception as e:  # noqa: BLE001
        return f"unknown ({type(e).__name__})"


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("experiment", choices=sorted(PLANS))
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--rush-concurrency", type=int, default=150)
    p.add_argument("--out", default="results.csv")
    p.add_argument("--quick", action="store_true", help="1 run, 1/10 of the requests (setup check only)")
    args = p.parse_args()

    plan = PLANS[args.experiment]
    repeats = plan["repeats"] or args.repeats
    runs = plan["runs"]
    if args.quick:
        repeats = 1
        runs = [(db, wl, max(10, req // 10), conc) for db, wl, req, conc in runs]
    if args.experiment == "rush":
        runs = [(db, wl, req, args.rush_concurrency) for db, wl, req, _ in runs]
        print(f"RDS max_connections = {rds_max_connections()}")

    if plan["warmup"]:
        print("Warming up both databases (not recorded)...")
        for db in ("rds", "dynamodb"):
            run_once(db, "read", 50, 1, os.path.join(tempfile.gettempdir(), "cs361_warmup.csv"))

    table = []
    for db, wl, req, conc in runs:
        rows = []
        errors = []
        for k in range(repeats):
            print(f"  running {db:8} {wl:11} concurrency {conc:3}  run {k + 1}/{repeats} ...", flush=True)
            row, first_error = run_once(db, wl, req, conc, args.out)
            rows.append(row)
            if first_error:
                errors.append(first_error)
        med = lambda key: statistics.median(float(r[key]) for r in rows)  # noqa: E731
        scanned = [float(r["items_scanned_avg"]) for r in rows if r["items_scanned_avg"]]
        table.append({
            "store": db, "workload": wl, "conc": conc,
            "p50": med("latency_p50_ms"), "p95": med("latency_p95_ms"), "rps": med("throughput_req_s"),
            "errors": sum(int(r["errors"]) for r in rows), "requests": req * repeats,
            "rows": med("rows_returned_avg"), "scanned": statistics.median(scanned) if scanned else None,
            "retries": sum(int(r["sdk_retries"]) for r in rows),
            "first_error": errors[0] if errors else "",
        })

    print()
    print(f"Experiment: {args.experiment}   (median of {repeats} run{'s' if repeats > 1 else ''}; "
          f"errors and retries are totals)")
    head = f"{'Store':9} {'Workload':12} {'Conc':>4} {'p50 ms':>9} {'p95 ms':>9} {'req/s':>9} " \
           f"{'Errors':>13} {'Retries':>7} {'Rows':>5} {'Scanned':>8}"
    print(head)
    print("-" * len(head))
    for t in table:
        scanned = f"{t['scanned']:.0f}" if t["scanned"] is not None else "-"
        errs = f"{t['errors']}/{t['requests']}"
        print(f"{t['store']:9} {t['workload']:12} {t['conc']:>4} {t['p50']:>9.2f} {t['p95']:>9.2f} "
              f"{t['rps']:>9.1f} {errs:>13} {t['retries']:>7} {t['rows']:>5.1f} {scanned:>8}")
    for t in table:
        if t["first_error"]:
            print(f"\nFirst error ({t['store']} {t['workload']}): {t['first_error'][:200]}")
    print(f"\nAll runs were also saved to {args.out}.")
    if args.experiment == "history":
        rows = {t["rows"] for t in table}
        print("Correctness: every store returned the same number of orders." if len(rows) == 1
              else "WARNING: the stores returned different numbers of orders. Tell your instructor.")


if __name__ == "__main__":
    main()
