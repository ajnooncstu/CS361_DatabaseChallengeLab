"""CS361 RDS vs DynamoDB teaching benchmark (v2, Cafe schema).

Workloads (all on the Cafe order data loaded by seed.py):
- read    : one order with its items, like the Order Confirmation page
            RDS = SELECT ... JOIN order_item, product WHERE order_number = ?
            DynamoDB = Query pk = ORDER#<order_number> (META + ITEM# items)
- write   : place one new order with 1-3 items, in one transaction
            RDS = INSERT `order` + INSERT order_item rows, COMMIT
            DynamoDB = TransactWriteItems (META + ITEM# items)
- history : the Order History page, limited to the 20 most recent orders
            RDS = the Cafe orderHistory.php query + LIMIT 20 orders
            DynamoDB = no key for "newest orders", so Scan every page and sort
- history-gsi (DynamoDB only): the same page through OrderHistoryIndex
            Query gsi1pk = ORDERS, newest first, Limit 20 (each META item carries its items)

Changes from v1
- Each worker thread REUSES one DB connection (RDS) / one boto3 client (DynamoDB),
  like a real application. Use --new-connection-per-request to reproduce the v1
  behaviour (connection setup is then included in every request's latency).
- history on DynamoDB scans the WHOLE table (all pages) and returns the 20 most
  recent orders, so both databases return the same answer.
- Output adds rows returned, items scanned (DynamoDB), SDK retries, and UTC
  start/end times for matching CloudWatch metrics. --out appends a CSV row.
"""
import argparse
import concurrent.futures as cf
import csv
import datetime as dt
import os
import statistics
import threading
import time

import boto3
import pymysql
from boto3.dynamodb.conditions import Key
from botocore.config import Config
from dotenv import load_dotenv

from cafe_data import ddb_items, new_order

load_dotenv()

HISTORY_LIMIT = 20
_local = threading.local()
_args = None  # set in main()


def pct(values, p):
    if not values:
        return 0.0
    xs = sorted(values)
    k = (len(xs) - 1) * (p / 100)
    f = int(k)
    c = min(f + 1, len(xs) - 1)
    if f == c:
        return xs[f]
    return xs[f] + (xs[c] - xs[f]) * (k - f)


# ---------------------------------------------------------------- RDS
def rds_connect():
    return pymysql.connect(
        host=os.environ["RDS_HOST"],
        port=int(os.getenv("RDS_PORT", "3306")),
        user=os.environ["RDS_USER"],
        password=os.environ["RDS_PASSWORD"],
        database=os.getenv("RDS_DATABASE", "cs361lab"),
        autocommit=True,
        connect_timeout=10,
        read_timeout=20,
        write_timeout=20,
    )


def rds_get_conn():
    """Per-thread reused connection (reconnects if the server dropped it)."""
    if _args.new_connection_per_request:
        return rds_connect()
    conn = getattr(_local, "rds", None)
    if conn is None or not conn.open:
        conn = rds_connect()
        _local.rds = conn
    return conn


ORDER_SQL = (
    "SELECT a.order_number, a.order_date_time, a.amount AS order_total, "
    "b.order_item_number, b.product_id, b.quantity, b.amount AS item_amount, c.product_name, c.price "
    "FROM `order` a JOIN order_item b ON a.order_number = b.order_number "
    "JOIN product c ON c.id = b.product_id "
)


def rds_op(mode, i):
    """Returns (rows_returned, items_scanned, retries)."""
    conn = rds_get_conn()
    try:
        with conn.cursor() as cur:
            if mode == "read":
                cur.execute(ORDER_SQL + "WHERE a.order_number = %s ORDER BY b.order_item_number",
                            (i % 1000 + 1,))
                return len(cur.fetchall()), None, 0
            if mode == "write":
                o = new_order(i)
                conn.begin()
                try:
                    cur.execute("INSERT INTO `order` (order_date_time, amount) VALUES (%s, %s)",
                                (o["order_date_time"], o["amount"]))
                    order_number = cur.lastrowid
                    cur.executemany(
                        "INSERT INTO order_item (order_number, order_item_number, product_id, quantity, amount) "
                        "VALUES (%s,%s,%s,%s,%s)",
                        [(order_number, it["order_item_number"], it["product_id"], it["quantity"], it["amount"])
                         for it in o["items"]],
                    )
                    conn.commit()
                except Exception:
                    conn.rollback()
                    raise
                return len(o["items"]), None, 0
            if mode == "history":
                cur.execute(
                    "SELECT a.order_number, a.order_date_time, a.amount AS order_total, "
                    "b.order_item_number, b.product_id, b.quantity, b.amount AS item_amount, c.product_name, c.price "
                    "FROM (SELECT order_number FROM `order` ORDER BY order_number DESC LIMIT %s) t "
                    "JOIN `order` a ON a.order_number = t.order_number "
                    "JOIN order_item b ON a.order_number = b.order_number "
                    "JOIN product c ON c.id = b.product_id "
                    "ORDER BY a.order_number DESC, b.order_item_number ASC",
                    (HISTORY_LIMIT,),
                )
                return len({row[0] for row in cur.fetchall()}), None, 0
            raise ValueError(mode)
    except pymysql.err.OperationalError:
        # drop a broken reused connection so the next request reconnects
        _local.rds = None
        raise
    finally:
        if _args.new_connection_per_request:
            conn.close()


# ---------------------------------------------------------------- DynamoDB
def ddb_make_table():
    # boto3 resources are not thread-safe: one Session per thread.
    session = boto3.session.Session(region_name=os.getenv("AWS_REGION", "us-east-1"))
    cfg = Config(max_pool_connections=max(10, _args.concurrency))
    return session.resource("dynamodb", config=cfg).Table(os.getenv("DDB_TABLE", "cs361-orders"))


def ddb_get_table():
    if _args.new_connection_per_request:
        return ddb_make_table()
    t = getattr(_local, "ddb", None)
    if t is None:
        t = ddb_make_table()
        _local.ddb = t
    return t


def _retries(resp):
    return resp.get("ResponseMetadata", {}).get("RetryAttempts", 0)


def ddb_op(mode, i):
    """Returns (rows_returned, items_scanned, retries)."""
    table = ddb_get_table()
    if mode == "read":
        r = table.query(KeyConditionExpression=Key("pk").eq(f"ORDER#{i % 1000 + 1}"))
        return sum(1 for x in r["Items"] if x["sk"].startswith("ITEM#")), None, _retries(r)
    if mode == "write":
        # DynamoDB has no AUTO_INCREMENT: the application must create a unique order number.
        o = new_order(i)
        order_number = (time.time_ns() // 1000) * 100 + i % 100
        items = ddb_items(order_number, o)
        # table.meta.client comes from a boto3 resource, so it converts Python values to
        # DynamoDB types itself: pass plain values, not TypeSerializer output.
        tx = [{"Put": {"TableName": table.name, "Item": it,
                       "ConditionExpression": "attribute_not_exists(pk)"}} for it in items]
        r = table.meta.client.transact_write_items(TransactItems=tx)
        return len(o["items"]), None, _retries(r)
    if mode == "history":
        # The starter key design (pk = ORDER#<order_number>) has no key for "newest orders",
        # so the only correct answer is to Scan EVERY page, then sort. Note: Scan's Limit caps
        # items *examined* per page, not results, so we must follow LastEvaluatedKey.
        everything, scanned, retries, kwargs = [], 0, 0, {}
        while True:
            r = table.scan(**kwargs)
            everything.extend(r.get("Items", []))
            scanned += r.get("ScannedCount", 0)
            retries += _retries(r)
            if "LastEvaluatedKey" not in r:
                break
            kwargs["ExclusiveStartKey"] = r["LastEvaluatedKey"]
        metas = [x for x in everything if x["sk"] == "META"]
        metas.sort(key=lambda x: (x["order_date_time"], x["order_number"]), reverse=True)
        newest = {m["pk"] for m in metas[:HISTORY_LIMIT]}
        _page = [x for x in everything if x["pk"] in newest]  # orders + their items, as the page shows
        return len(newest), scanned, retries
    if mode == "history-gsi":
        r = table.query(IndexName="OrderHistoryIndex", KeyConditionExpression=Key("gsi1pk").eq("ORDERS"),
                        ScanIndexForward=False, Limit=HISTORY_LIMIT)
        return len(r["Items"]), r.get("ScannedCount", 0), _retries(r)
    raise ValueError(mode)


# ---------------------------------------------------------------- harness
def one_call(db, mode, i):
    t0 = time.perf_counter()
    try:
        rows, scanned, retries = (rds_op if db == "rds" else ddb_op)(mode, i)
        return True, (time.perf_counter() - t0) * 1000, "", rows, scanned, retries
    except Exception as e:  # noqa: BLE001 - we want to count every failure
        return False, (time.perf_counter() - t0) * 1000, f"{type(e).__name__}: {e}", 0, None, 0


def main():
    global _args
    p = argparse.ArgumentParser(description="CS361 RDS vs DynamoDB teaching benchmark (v2)")
    p.add_argument("--db", choices=["rds", "dynamodb"], required=True)
    p.add_argument("--workload", choices=["read", "write", "history", "history-gsi"], required=True)
    p.add_argument("--requests", type=int, default=1000)
    p.add_argument("--concurrency", type=int, default=10)
    p.add_argument("--new-connection-per-request", action="store_true",
                   help="open a new DB connection / boto3 client for every request (v1 behaviour)")
    p.add_argument("--out", help="append one result row to this CSV file")
    _args = p.parse_args()
    if _args.workload == "history-gsi" and _args.db != "dynamodb":
        p.error("history-gsi is a DynamoDB design; RDS already uses its primary key (run --workload history)")

    started_utc = dt.datetime.now(dt.timezone.utc)
    started = time.perf_counter()
    ok_lat, err_lat, errors, rows, scanned, retries = [], [], [], [], [], 0
    with cf.ThreadPoolExecutor(max_workers=_args.concurrency) as ex:
        futures = [ex.submit(one_call, _args.db, _args.workload, i) for i in range(_args.requests)]
        for fut in cf.as_completed(futures):
            ok, ms, err, n, s, r = fut.result()
            retries += r
            if ok:
                ok_lat.append(ms)
                rows.append(n)
                if s is not None:
                    scanned.append(s)
            else:
                err_lat.append(ms)
                errors.append(err)
    elapsed = time.perf_counter() - started
    ended_utc = dt.datetime.now(dt.timezone.utc)

    success = len(ok_lat)
    res = {
        "db": _args.db,
        "workload": _args.workload,
        "connection": "new-per-request" if _args.new_connection_per_request else "reused-per-thread",
        "requests": _args.requests,
        "concurrency": _args.concurrency,
        "success": success,
        "errors": len(errors),
        "sdk_retries": retries,
        "elapsed_s": round(elapsed, 3),
        "throughput_req_s": round(success / elapsed, 2) if elapsed else 0,
        "latency_p50_ms": round(pct(ok_lat, 50), 2),
        "latency_p95_ms": round(pct(ok_lat, 95), 2),
        "latency_mean_ms": round(statistics.mean(ok_lat), 2) if ok_lat else 0,
        "rows_returned_avg": round(statistics.mean(rows), 1) if rows else 0,
        "items_scanned_avg": round(statistics.mean(scanned), 1) if scanned else "",
        "start_utc": started_utc.strftime("%Y-%m-%d %H:%M:%S"),
        "end_utc": ended_utc.strftime("%Y-%m-%d %H:%M:%S"),
    }

    print("=" * 58)
    for k, v in res.items():
        if v != "":
            print(f"{k}={v}")
    if errors:
        print("first_error=", errors[0])
    if retries:
        print("note: sdk_retries > 0 means some requests were retried (e.g. throttling); "
              "check CloudWatch ThrottledRequests.")
    print("=" * 58)

    if _args.out:
        new = not os.path.exists(_args.out)
        with open(_args.out, "a", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(res))
            if new:
                w.writeheader()
            w.writerow(res)


if __name__ == "__main__":
    main()
